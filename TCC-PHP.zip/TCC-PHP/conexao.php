<?php
$servername = "localhost";
$username = "root"; // Substitua pelo seu usuário do MySQL
$password = ""; // Substitua pela sua senha do MySQL
$database = "oxilifetcc";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // Definindo o modo de erro do PDO para exceção
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conectado com sucesso";
} catch (PDOException $e) {
    echo "Falha na conexão: " . $e->getMessage();
}
?>
