<?php
include 'db.php';

try {
    $sql = "UPDATE Clientes SET nome = :nome WHERE cliente_id = :cliente_id";
    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':cliente_id', $cliente_id);
    $stmt->bindParam(':nome', $nome);

    // Valores a serem atualizados
    $cliente_id = 1;
    $nome = "João Silva Atualizado";

    $stmt->execute();
    echo "Cliente atualizado com sucesso";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
