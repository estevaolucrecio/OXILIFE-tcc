<?php
include 'db.php';

try {
    $sql = "INSERT INTO Galao (galao_id, descricao, preco_unitario, quantidade_estoque) VALUES (:galao_id, :descricao, :preco_unitario, :quantidade_estoque)";
    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':galao_id', $galao_id);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':preco_unitario', $preco_unitario);
    $stmt->bindParam(':quantidade_estoque', $quantidade_estoque);

    // Valores a serem inseridos
    $galao_id = 1;
    $descricao = "Galão de 5L";
    $preco_unitario = 50.00;
    $quantidade_estoque = 100;

    $stmt->execute();
    echo "Galão inserido com sucesso";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
