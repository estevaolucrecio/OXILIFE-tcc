<?php
include 'db.php';

try {
    $sql = "INSERT INTO Clientes (cliente_id, nome, endereco, telefone, email) VALUES (:cliente_id, :nome, :endereco, :telefone, :email)";
    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':cliente_id', $cliente_id);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':endereco', $endereco);
    $stmt->bindParam(':telefone', $telefone);
    $stmt->bindParam(':email', $email);

    // Valores a serem inseridos
    $cliente_id = 1;
    $nome = "João Silva";
    $endereco = "Rua A, 123";
    $telefone = "123456789";
    $email = "joao.silva@example.com";

    $stmt->execute();
    echo "Cliente inserido com sucesso";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
