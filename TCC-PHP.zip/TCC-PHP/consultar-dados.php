<?php
include 'db.php';

try {
    $sql = "SELECT * FROM Clientes";
    $stmt = $pdo->query($sql);
    
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($clientes as $cliente) {
        echo "ID: " . $cliente['cliente_id'] . "<br>";
        echo "Nome: " . $cliente['nome'] . "<br>";
        echo "Endereço: " . $cliente['endereco'] . "<br>";
        echo "Telefone: " . $cliente['telefone'] . "<br>";
        echo "Email: " . $cliente['email'] . "<br><br>";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
