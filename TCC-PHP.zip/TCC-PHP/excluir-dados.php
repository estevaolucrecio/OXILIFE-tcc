<?php
include 'db.php';

try {
    $sql = "DELETE FROM Clientes WHERE cliente_id = :cliente_id";
    $stmt = $pdo->prepare($sql);
    
    $stmt->bindParam(':cliente_id', $cliente_id);

    // ID do cliente a ser excluído
    $cliente_id = 1;

    $stmt->execute();
    echo "Cliente excluído com sucesso";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
